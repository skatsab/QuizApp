package com.example.quiz

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun QuizScreen(navController: NavController, viewModel: QuizViewModel) {
    val question = viewModel.getCurrentQuestion()

    var selectedAnswer by remember { mutableStateOf(-1) }
    var answerSubmitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Punktestand oben anzeigen
        Text("Punkte: ${viewModel.getScore()} / ${viewModel.getTotalQuestions()}", fontSize = 18.sp)

        Spacer(modifier = Modifier.height(8.dp))

        Text(question.text, fontSize = 20.sp)

        // Antwortfelder als Boxen
        question.answers.forEachIndexed { index, answer ->
            val isCorrect = index == question.correctAnswerIndex
            val isSelected = index == selectedAnswer

            val backgroundColor = when {
                !answerSubmitted -> Color(0xFFE0E0E0)
                isCorrect -> Color(0xFF4CAF50) // grün
                isSelected -> Color(0xFFF44336) // rot
                else -> Color(0xFFE0E0E0)
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(backgroundColor)
                    .padding(12.dp)
                    .clickable(enabled = !answerSubmitted) {
                        selectedAnswer = index
                        answerSubmitted = true
                        viewModel.submitAnswer(index)
                    }
            ) {
                Text(answer, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (viewModel.isLastQuestion()) {
                    navController.navigate("result")
                } else {
                    viewModel.nextQuestion()
                    selectedAnswer = -1
                    answerSubmitted = false
                }
            },
            enabled = answerSubmitted,
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Weiter")
        }
    }
}
