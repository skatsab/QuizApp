package com.example.quiz

import androidx.lifecycle.ViewModel

class QuizViewModel(
    private val questions: List<Question> = listOf(
        Question("Was ist 2 + 2?", listOf("3", "4", "5"), 1),
        Question("Hauptstadt von Deutschland?", listOf("Berlin", "München", "Köln"), 0),
        Question("Wieviele Tage hat eine Woche?", listOf("5", "6", "7"), 2)
    )
) : ViewModel() {

    private var currentQuestionIndex = 0
    private var score = 0

    fun getCurrentQuestion(): Question = questions[currentQuestionIndex]

    fun submitAnswer(answerIndex: Int) {
        if (answerIndex == questions[currentQuestionIndex].correctAnswerIndex) {
            score++
        }
    }

    fun nextQuestion() {
        if (currentQuestionIndex < questions.size - 1) {
            currentQuestionIndex++
        }
    }

    fun isLastQuestion(): Boolean = currentQuestionIndex >= questions.size - 1

    fun getScore(): Int = score

    fun getTotalQuestions(): Int = questions.size

    fun reset() {
        currentQuestionIndex = 0
        score = 0
    }
}
