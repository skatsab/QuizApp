package com.example.quiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.quiz.ui.theme.QuizTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuizTheme {
                QuizAppNavigation()
            }
        }
    }
}

@Composable
fun QuizAppNavigation() {
    val navController = rememberNavController()
    val quizViewModel: QuizViewModel = viewModel()

    NavHost(navController = navController, startDestination = "start") {
        composable("start") {
            StartScreen(navController)
        }
        composable("quiz") {
            QuizScreen(navController, quizViewModel)
        }
        composable("result") {
            ResultScreen(navController, quizViewModel)
        }
    }
}

@Composable
fun StartScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Willkommen zum Quiz!", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = { navController.navigate("quiz") }) {
            Text("Start")
        }
    }
}

@Composable
fun ResultScreen(navController: NavController, viewModel: QuizViewModel) {
    val score = viewModel.getScore()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ergebnis", fontSize = 28.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Dein Score: $score / ${viewModel.getTotalQuestions()}", fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            viewModel.reset()
            navController.navigate("start") {
                popUpTo("start") { inclusive = true }
            }
        }) {
            Text("Nochmal spielen")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    QuizTheme {
        val dummyQuestion = Question("Was ist 2+2?", listOf("3", "4", "5"), 1)
        val vm = QuizViewModel(listOf(dummyQuestion))
        QuizScreen(navController = rememberNavController(), viewModel = vm)
    }
}
